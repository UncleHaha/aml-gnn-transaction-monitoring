"""
IBM IT-AML (Anti-Money Laundering) dataset loader.

Constructs an account-as-node graph from the IBM IT-AML transaction CSV
(downloaded from Kaggle), with parsing of the ground-truth laundering
typology annotations from Patterns.txt.

The Patterns.txt format observed in HI-Small_Patterns.txt:
    BEGIN LAUNDERING ATTEMPT - FAN-OUT:  Max 16-degree Fan-Out
    2022/09/01 00:06,021174,800737690,012,80011F990,...,1
    ...
    END LAUNDERING ATTEMPT - FAN-OUT

CRITICAL detail: the timestamps in Patterns.txt are kept as the original
"YYYY/MM/DD HH:MM" string (no seconds, with forward slashes). We must match
against the RAW timestamp string from the CSV before pandas converts it to a
datetime, otherwise every key will miss.

Note on the chronological split: the train/val/test split is by ACCOUNT FIRST
APPEARANCE, not by edge time. Combined with the fact that IT-AML laundering
campaigns escalate over the simulation window, this typically produces a test
set with a lower illicit-account rate than training. This is methodologically
sound -- the model is being tested on its ability to flag new accounts -- but
test AUC-PR will tend to be lower than validation AUC-PR, which is expected
and should be reported as such in Chapter 5.
"""
import torch
from torch_geometric.data import Data
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Tuple, Dict


def _parse_patterns_file(patterns_path: Path) -> Dict[str, str]:
    """
    Parse IT-AML Patterns.txt into a mapping from transaction key -> typology.

    Key format: "raw_timestamp_string,from_bank,from_acc,to_bank,to_acc"
    where the timestamp is preserved exactly as written in the file
    (e.g. "2022/09/01 00:06", with slashes and no seconds).

    The typology label is extracted from the "BEGIN LAUNDERING ATTEMPT - X:..."
    line, taking just the "X" portion before the colon (e.g. "FAN-OUT").
    """
    if not patterns_path.exists():
        return {}

    typology_map: Dict[str, str] = {}
    current_typology = None

    with open(patterns_path, "r") as f:
        for line in f:
            line = line.rstrip("\n").rstrip()
            if not line:
                continue
            if line.startswith("BEGIN LAUNDERING ATTEMPT"):
                # Format: "BEGIN LAUNDERING ATTEMPT - <TYPOLOGY>: <description>"
                # We want just the <TYPOLOGY> portion.
                tag = line.split("-", 1)[-1].strip()
                tag = tag.split(":", 1)[0].strip()
                current_typology = tag
            elif line.startswith("END LAUNDERING ATTEMPT"):
                current_typology = None
            elif current_typology is not None:
                parts = line.split(",")
                if len(parts) >= 5:
                    # ts, from_bank, from_acc, to_bank, to_acc
                    key = ",".join(parts[:5])
                    typology_map[key] = current_typology
    return typology_map


def load_itaml(
        csv_path: str = "data/it_aml/HI-Small_Trans.csv",
        patterns_path: str | None = None,
        chronological_split: tuple = (0.7, 0.15, 0.15),
) -> Tuple[Data, dict]:
    """
    Load the IT-AML dataset and construct an account-as-node graph.

    Parameters
    ----------
    csv_path : str
        Path to the transactions CSV (e.g. HI-Small_Trans.csv).
    patterns_path : str or None
        Path to the laundering patterns file (HI-Small_Patterns.txt). If None
        or file missing, typology labels are omitted (typology-alignment
        evaluation will be unavailable).
    chronological_split : tuple of three floats summing to 1.0
        Fractions for train/val/test based on chronological order of
        account first-appearance.

    Returns
    -------
    data : torch_geometric.data.Data
        Graph with x, edge_index, edge_attr, y, train_mask, val_mask, test_mask,
        and (if patterns file is present and parsed) edge_typology.
    info : dict
        Dataset metadata. `has_typology_annotations` is True only when
        annotations were actually parsed.
    """
    csv_path = Path(csv_path)
    if not csv_path.exists():
        raise FileNotFoundError(f"IT-AML transactions file not found at {csv_path}.")

    # ----- 1. Load transactions -----
    df = pd.read_csv(csv_path, dtype={
    "From Bank": str,
    "Account": str,
    "To Bank": str,
    "Account.1": str,
    })
    df.columns = [c.strip() for c in df.columns]

    rename_map = {}
    if "From Bank Account" in df.columns:
        rename_map["From Bank Account"] = "Account"
    elif "From Account" in df.columns:
        rename_map["From Account"] = "Account"
    if "To Bank Account" in df.columns:
        rename_map["To Bank Account"] = "Account.1"
    elif "To Account" in df.columns:
        rename_map["To Account"] = "Account.1"
    df = df.rename(columns=rename_map)

    # CRITICAL: Preserve the raw timestamp string for typology key-matching,
    # BEFORE pandas converts to datetime. The patterns file uses the original
    # "YYYY/MM/DD HH:MM" format; converted datetimes would not match.
    df["Timestamp_raw"] = df["Timestamp"].astype(str).str.strip()

    df["Timestamp"] = pd.to_datetime(df["Timestamp"])
    df = df.sort_values("Timestamp").reset_index(drop=True)

    # ----- 2. Build account index -----
    df["from_id"] = df["From Bank"].astype(str) + "_" + df["Account"].astype(str)
    df["to_id"] = df["To Bank"].astype(str) + "_" + df["Account.1"].astype(str)
    all_accounts = pd.concat([df["from_id"], df["to_id"]]).unique()
    acc_to_idx = {acc: i for i, acc in enumerate(all_accounts)}
    n_nodes = len(acc_to_idx)

    src = df["from_id"].map(acc_to_idx).values.astype(np.int64)
    dst = df["to_id"].map(acc_to_idx).values.astype(np.int64)
    edge_index = torch.tensor(np.stack([src, dst]), dtype=torch.long)

    # ----- 3. Build edge features -----
    df["payment_format_id"] = df["Payment Format"].astype("category").cat.codes
    df["currency_id"] = df["Payment Currency"].astype("category").cat.codes

    edge_attr = torch.tensor(
        np.stack([
            df["Amount Paid"].values.astype(np.float32),
            df["payment_format_id"].values.astype(np.float32),
            df["currency_id"].values.astype(np.float32),
        ], axis=1),
        dtype=torch.float32,
    )

    # ----- 3b. Parse typology annotations -----
    # Uses Timestamp_raw (not Timestamp) so the key format matches the
    # patterns file exactly.
    edge_typology = None
    if patterns_path is not None:
        typology_map = _parse_patterns_file(Path(patterns_path))
        if typology_map:
            keys = (
                df["Timestamp_raw"] + ","
                + df["From Bank"].astype(str) + ","
                + df["Account"].astype(str) + ","
                + df["To Bank"].astype(str) + ","
                + df["Account.1"].astype(str)
            )
            edge_typology = [typology_map.get(k, "None") for k in keys]
            n_labelled = sum(1 for t in edge_typology if t != "None")
            print(f"[itaml_loader] Parsed {n_labelled:,} typology-labelled edges "
                  f"out of {len(edge_typology):,} total")

    # ----- 4. Build node features -----
    out_agg = df.groupby("from_id").agg(
        out_count=("Amount Paid", "count"),
        out_sum=("Amount Paid", "sum"),
        out_mean=("Amount Paid", "mean"),
        out_std=("Amount Paid", "std"),
        n_unique_to=("to_id", "nunique"),
    ).fillna(0.0)

    in_agg = df.groupby("to_id").agg(
        in_count=("Amount Received", "count"),
        in_sum=("Amount Received", "sum"),
        in_mean=("Amount Received", "mean"),
        in_std=("Amount Received", "std"),
        n_unique_from=("from_id", "nunique"),
    ).fillna(0.0)

    feat_df = pd.DataFrame(index=all_accounts)
    feat_df = feat_df.join(out_agg).join(in_agg).fillna(0.0)
    x = torch.tensor(feat_df.values, dtype=torch.float32)

    # ----- 5. Build node labels -----
    laundering_from = set(df.loc[df["Is Laundering"] == 1, "from_id"])
    laundering_to = set(df.loc[df["Is Laundering"] == 1, "to_id"])
    laundering_accounts = laundering_from.union(laundering_to)
    y = torch.tensor(
        [1 if acc in laundering_accounts else 0 for acc in all_accounts],
        dtype=torch.long,
    )

    # ----- 6. Vectorised Chronological Split (O(N log N)) -----
    # An account is assigned to a split by its FIRST APPEARANCE in the data.
    # Combined with IT-AML's escalating laundering pattern, this typically
    # gives a stricter test set (mostly brand-new accounts).
    min_from = df.groupby("from_id")["Timestamp"].min()
    min_to = df.groupby("to_id")["Timestamp"].min()

    times_df = pd.DataFrame(index=all_accounts)
    times_df = times_df.join(min_from.rename("min_f")).join(min_to.rename("min_t"))
    times_series = times_df[["min_f", "min_t"]].min(axis=1)

    q_train = times_series.quantile(chronological_split[0])
    q_val = times_series.quantile(chronological_split[0] + chronological_split[1])

    train_mask = torch.tensor((times_series <= q_train).values, dtype=torch.bool)
    val_mask = torch.tensor(((times_series > q_train) & (times_series <= q_val)).values,
                            dtype=torch.bool)
    test_mask = torch.tensor((times_series > q_val).values, dtype=torch.bool)

    # ----- 7. Standardise Node Features (training-set statistics only) -----
    x_train = x[train_mask].view(-1, x.size(-1))
    mean = x_train.mean(dim=0, keepdim=True)
    std = x_train.std(dim=0, keepdim=True).clamp(min=1e-6)
    x = (x - mean) / std

    # ----- 8. Build the PyG Data Object -----
    data = Data(
        x=x,
        edge_index=edge_index,
        edge_attr=edge_attr,
        y=y,
        train_mask=train_mask,
        val_mask=val_mask,
        test_mask=test_mask,
    )
    if edge_typology is not None:
        data.edge_typology = edge_typology   # plain Python list of strings

    info = {
        "num_nodes": n_nodes,
        "num_edges": int(edge_index.shape[1]),
        "num_features": int(x.shape[1]),
        "num_classes": 2,
        "train_count": int(train_mask.sum()),
        "val_count": int(val_mask.sum()),
        "test_count": int(test_mask.sum()),
        "train_illicit": int(y[train_mask].sum()),
        "val_illicit": int(y[val_mask].sum()),
        "test_illicit": int(y[test_mask].sum()),
        "has_typology_annotations": edge_typology is not None,
    }
    return data, info


if __name__ == "__main__":
    try:
        data, info = load_itaml(
            csv_path="data/it_aml/HI-Small_Trans.csv",
            patterns_path="data/it_aml/HI-Small_Patterns.txt",
        )
        print("IT-AML Dataset loaded successfully:")
        for k, v in info.items():
            print(f"  {k}: {v}")
        if hasattr(data, "edge_typology"):
            from collections import Counter
            print("\nTypology distribution:")
            for typ, cnt in Counter(data.edge_typology).most_common():
                print(f"  {typ}: {cnt:,}")
    except Exception as e:
        print(f"Execution failed: {e}")
