"""
Elliptic Bitcoin dataset loader.

The Elliptic dataset is integrated into PyTorch Geometric as
`EllipticBitcoinDataset`. This module wraps it with chronological train/val/test
splitting following the convention established by Weber et al. (2019):

    - Train: time steps 1-34
    - Val:   time steps 35-39
    - Test:  time steps 40-49

Unknown-labelled nodes are kept in the graph for message passing but are
excluded from loss computation and evaluation.

IMPORTANT: PyG's `EllipticBitcoinDataset.process()` DROPS the time_step column
from `data.x` (it keeps only columns 2 onwards as features). So `data.x[:, 0]`
is NOT the time step -- it is the first feature. To get time steps, we must
read them from the raw features CSV that PyG downloads.
"""
from pathlib import Path
from typing import Tuple

import pandas as pd
import torch
from torch_geometric.data import Data
from torch_geometric.datasets import EllipticBitcoinDataset

# Time step boundaries for chronological split (1-indexed in the dataset)
TRAIN_END_STEP = 34
VAL_END_STEP = 39
TOTAL_STEPS = 49


def _find_raw_features_csv(root: str) -> Path:
    """Locate the elliptic_txs_features.csv that PyG downloaded.

    PyG places raw files under different subdirectories depending on the
    version, so we search common locations and fall back to recursive search.
    """
    root_path = Path(root)
    candidates = [
        root_path / "raw" / "elliptic_txs_features.csv",
        root_path / "elliptic_bitcoin_dataset" / "raw" / "elliptic_txs_features.csv",
        root_path / "EllipticBitcoinDataset" / "raw" / "elliptic_txs_features.csv",
        root_path / "raw" / "elliptic_bitcoin_dataset_cont" / "elliptic_txs_features.csv",
    ]
    for c in candidates:
        if c.exists():
            return c
    matches = list(root_path.rglob("elliptic_txs_features.csv"))
    if matches:
        return matches[0]
    raise FileNotFoundError(
        f"Could not find elliptic_txs_features.csv under {root}. "
        f"Searched: {[str(c) for c in candidates]}"
    )


def load_elliptic(root: str = "data/elliptic") -> Tuple[Data, dict]:
    """
    Load the Elliptic Bitcoin dataset with chronological masks.

    Returns
    -------
    data : torch_geometric.data.Data
        Graph with x, edge_index, y, train_mask, val_mask, test_mask attributes.
    info : dict
        Metadata about the dataset (num nodes, num edges, class counts).
    """
    Path(root).mkdir(parents=True, exist_ok=True)
    dataset = EllipticBitcoinDataset(root=root)
    data = dataset[0]

    # ----- Get time steps from the raw CSV -----
    # PyG drops the time_step column when building data.x, so we re-read it.
    # In the raw CSV: column 0 = txId, column 1 = time_step, columns 2+ = features.
    # PyG processes nodes in the same order as the CSV, so row i of the CSV
    # corresponds to node i in the data object.
    features_csv = _find_raw_features_csv(root)
    df = pd.read_csv(features_csv, header=None)
    time_steps = torch.tensor(df[1].values, dtype=torch.long)

    if len(time_steps) != data.num_nodes:
        raise RuntimeError(
            f"Time step count ({len(time_steps)}) does not match number of "
            f"nodes ({data.num_nodes}). Check the raw features file format."
        )

    # ----- Build chronological masks -----
    # PyG's train_mask/test_mask together cover all LABELLED nodes (y != 2).
    # We override the split using literature convention.
    is_labelled = data.train_mask | data.test_mask
    train_mask = is_labelled & (time_steps <= TRAIN_END_STEP)
    val_mask = is_labelled & (time_steps > TRAIN_END_STEP) & (time_steps <= VAL_END_STEP)
    test_mask = is_labelled & (time_steps > VAL_END_STEP)

    # ----- Sanity checks (fail loudly if anything is wrong) -----
    if int(train_mask.sum()) == 0:
        raise RuntimeError("Training set is empty after split.")
    if int(val_mask.sum()) == 0:
        raise RuntimeError("Validation set is empty after split.")
    if int(test_mask.sum()) == 0:
        raise RuntimeError("Test set is empty after split.")

    val_classes = data.y[val_mask].unique()
    test_classes = data.y[test_mask].unique()
    if val_classes.numel() < 2:
        raise RuntimeError(
            f"Validation set contains only one class: {val_classes.tolist()}. "
            f"Cannot compute AUC. Check time-step extraction."
        )
    if test_classes.numel() < 2:
        raise RuntimeError(
            f"Test set contains only one class: {test_classes.tolist()}. "
            f"Cannot compute AUC. Check time-step extraction."
        )

    data.train_mask = train_mask
    data.val_mask = val_mask
    data.test_mask = test_mask

    # ----- Normalise features using training-set statistics only -----
    x_train = data.x[train_mask]
    mean = x_train.mean(dim=0, keepdim=True)
    std = x_train.std(dim=0, keepdim=True).clamp(min=1e-6)
    data.x = (data.x - mean) / std

    # ----- Gather metadata -----
    info = {
        "num_nodes": data.num_nodes,
        "num_edges": data.num_edges,
        "num_features": data.num_features,
        "num_classes": 2,
        "train_count": int(train_mask.sum()),
        "val_count": int(val_mask.sum()),
        "test_count": int(test_mask.sum()),
        "train_illicit": int(data.y[train_mask].sum()),
        "val_illicit": int(data.y[val_mask].sum()),
        "test_illicit": int(data.y[test_mask].sum()),
        "train_time_steps": (
            int(time_steps[train_mask].min()),
            int(time_steps[train_mask].max()),
        ),
        "val_time_steps": (
            int(time_steps[val_mask].min()),
            int(time_steps[val_mask].max()),
        ),
        "test_time_steps": (
            int(time_steps[test_mask].min()),
            int(time_steps[test_mask].max()),
        ),
    }
    return data, info


if __name__ == "__main__":
    data, info = load_elliptic()
    print("Elliptic dataset loaded successfully:")
    for k, v in info.items():
        print(f"  {k}: {v}")
    print()
    print("Class distribution:")
    for split in ["train", "val", "test"]:
        n = info[f"{split}_count"]
        n_illicit = info[f"{split}_illicit"]
        pct = 100.0 * n_illicit / max(n, 1)
        print(f"  {split}: n={n}, illicit={n_illicit} ({pct:.2f}%)")
