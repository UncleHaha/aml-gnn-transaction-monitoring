# AML-GNN Thesis: Explainable Graph Neural Networks for Anti-Money Laundering

Code for the experimental component of the thesis *"Explainable Graph Neural Networks for Anti-Money Laundering: Evaluating Typology-Aligned Explanations in Transaction Monitoring."*

This codebase implements the 90 primary detection runs described in **Chapter 3, Section 3.11.1**:

| Factor | Options | Count |
| --- | --- | --- |
| Architectures | GCN, GAT, GraphSAGE | 3 |
| Imbalance strategies | Weighted CE, Focal Loss, GraphSMOTE | 3 |
| Datasets | Elliptic, IT-AML (HI-Small) | 2 |
| Random seeds | 0, 1, 2, 3, 4 | 5 |
| **Total** | | **90** |

---

## 1. Setup

### Python environment

```bash
# Create a fresh virtual environment (recommended)
python -m venv .venv
source .venv/bin/activate   # macOS/Linux
# .venv\Scripts\activate    # Windows

# Install dependencies
pip install --upgrade pip
pip install -r requirements.txt
```

> **PyTorch Geometric note.** If `pip install torch-geometric` fails on your system, install with the official wheel selector at https://pytorch-geometric.readthedocs.io/en/latest/install/installation.html. PyG wheels are tied to your PyTorch and CUDA versions.

### Verify the installation

```bash
python -c "import torch; import torch_geometric; print(torch.__version__, torch_geometric.__version__)"
```

---

## 2. Datasets

### 2.1 Elliptic (auto-downloaded)

The Elliptic dataset is built into PyTorch Geometric and downloads automatically the first time it is loaded. Nothing to do manually.

```bash
# Optional: trigger the download now
python -m src.data.elliptic_loader
```

The download goes to `data/elliptic/`.

### 2.2 IT-AML (manual download required)

The IBM IT-AML dataset must be downloaded from Kaggle:

1. Go to https://www.kaggle.com/datasets/ealtman2019/ibm-transactions-for-anti-money-laundering-aml
2. Download the zip file (Kaggle account required; the dataset is free).
3. Extract into `data/it_aml/`, so the layout is:

```
data/it_aml/
    HI-Small_Trans.csv
    HI-Small_Patterns.txt
    LI-Small_Trans.csv
    LI-Small_Patterns.txt
    ... (and other variants if downloaded)
```

Then verify:

```bash
python -m src.data.itaml_loader
```

> **If you don't have IT-AML yet**, you can still run the Elliptic experiments. See "Running the experiments" below.

---

## 3. Running the experiments

### 3.1 Smoke test (run 1 configuration, ~2-5 minutes)

```bash
python scripts/run_experiments.py --dataset elliptic --architecture gcn --imbalance_strategy weighted_ce --seed 0
```

This runs a single GCN + Elliptic + Weighted CE + seed 0 configuration. Confirm you see:

- Dataset loaded successfully
- Training epochs printing every 10 epochs
- Final test metrics with AUC-PR > 0.1 (on Elliptic, a working baseline is around 0.4-0.6)
- A JSON result file in `results/elliptic__gcn__weighted_ce__seed0.json`

### 3.2 Elliptic only (30 runs)

```bash
python scripts/run_experiments.py --dataset elliptic
```

### 3.3 Full 90 runs (only after IT-AML is downloaded)

```bash
python scripts/run_experiments.py
```

### 3.4 Aggregate results into a summary table

```bash
python scripts/aggregate_results.py
```

This produces `results/_summary_aggregated.csv` with mean ± std across the 5 seeds per configuration — directly suitable for the Chapter 5 results table.

### 3.5 Useful CLI options

| Flag | Purpose |
| --- | --- |
| `--dataset {elliptic,itaml}` | Restrict to one dataset |
| `--architecture {gcn,gat,graphsage}` | Restrict to one architecture |
| `--imbalance_strategy {weighted_ce,focal,graphsmote}` | Restrict to one strategy |
| `--seed N` | Restrict to one seed |
| `--max-runs N` | Cap the number of runs (e.g. `--max-runs 1` for smoke test) |

---

## 4. Project structure

```
aml_gnn_thesis/
├── README.md
├── requirements.txt
├── configs/
│   └── experiments.py          # Defines all 90 configurations
├── data/                       # Datasets (gitignored)
│   ├── elliptic/               # Auto-downloaded
│   └── it_aml/                 # Manual download from Kaggle
├── src/
│   ├── utils.py                # Seeds, device, logging
│   ├── data/
│   │   ├── elliptic_loader.py
│   │   └── itaml_loader.py
│   ├── models/
│   │   └── gnn_models.py       # GCN, GAT, GraphSAGE
│   ├── losses/
│   │   └── losses.py           # Weighted CE, Focal Loss
│   ├── sampling/
│   │   └── graphsmote.py       # Simplified GraphSMOTE
│   └── training/
│       ├── metrics.py          # AUC-PR, F1, Recall@k
│       └── trainer.py          # Training loop + early stopping
├── scripts/
│   ├── run_experiments.py      # Main runner
│   └── aggregate_results.py    # Summary table builder
├── results/                    # Per-run JSON results (gitignored)
└── logs/                       # Training logs (gitignored)
```

---

## 5. Compute expectations

These are rough estimates for a single GPU (e.g. NVIDIA RTX 3060 / Colab T4):

| Stage | Time per run | Total |
| --- | --- | --- |
| Elliptic + GCN | ~30 s | — |
| Elliptic + GAT | ~60 s | — |
| Elliptic + GraphSAGE | ~30 s | — |
| IT-AML + any model | ~3-10 min (data-size dependent) | — |
| **All 30 Elliptic runs** | | ~30 min |
| **All 60 IT-AML runs** | | ~5-10 hours |
| **All 90 runs** | | ~5-10 hours |

If running on CPU only, expect Elliptic to take ~10× longer and IT-AML to be impractical.

---

## 6. Extending the codebase

The code is intentionally modular. Where you'll typically add things:

| What you want to do | Where to change it |
| --- | --- |
| Add a new architecture (e.g. graph transformer) | `src/models/gnn_models.py` + register in `build_model()` |
| Add a new loss (e.g. enhanced focal loss) | `src/losses/losses.py` + register in `build_loss()` |
| Add a new dataset | new file in `src/data/`, then dispatch in `scripts/run_experiments.py::load_dataset` |
| Tune hyperparameters | edit `configs/experiments.py` (or wrap in Optuna later) |
| Add typology-alignment evaluation (Chapter 3 §3.8) | new file `src/training/typology_alignment.py` — **next milestone** |
| Add explainability integration | new file `src/explain/` package — **after detection is solid** |

---

## 7. Known limitations of this version

The following are deliberately left for subsequent development phases. They are flagged here so you don't expect them to work yet:

- **Typology-alignment evaluation (§3.8)**: not implemented in this version. The IT-AML loader extracts `edge_typology` from the patterns file, ready to be consumed by a future evaluator.
- **Explainability integration (§3.7)**: GNNExplainer / PGExplainer / GAT-Attention not wired in. PyG provides these out of the box; integration is a separate phase.
- **GraphSMOTE simplification (§3.6.1)**: this implementation uses feature interpolation + edge copying rather than the full edge-predictor variant from Zhao et al. (2021). This is documented in Chapter 4.
- **Heterogeneous and temporal extensions (§3.5.5)**: not implemented in this version; positioned as scope-extending.
- **Hyperparameter tuning with Optuna (§3.11.2)**: hyperparameters are currently fixed; Optuna integration is a follow-up task.

---

## 8. Reproducibility

- All experiments use fixed random seeds.
- The full software environment is captured in `requirements.txt`.
- Each run's exact configuration is saved in its result JSON file.
- The git commit hash should be recorded with each batch run (add `git rev-parse HEAD` to your logging if running on a server).

---

## 9. References

- Weber et al. (2019). Anti-money laundering in Bitcoin: Experimenting with GCNs for financial forensics. arXiv:1908.02591.
- Altman et al. (2023). Realistic synthetic financial transactions for anti-money laundering models. NeurIPS.
- Kipf & Welling (2017). Semi-supervised classification with graph convolutional networks. ICLR.
- Veličković et al. (2018). Graph attention networks. ICLR.
- Hamilton et al. (2017). Inductive representation learning on large graphs. NeurIPS.
- Lin et al. (2017). Focal loss for dense object detection. ICCV.
- Zhao et al. (2021). GraphSMOTE: Imbalanced node classification on graphs. WSDM.
